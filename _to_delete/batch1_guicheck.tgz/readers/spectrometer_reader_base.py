"""
spectrometer_reader_base.py — shared interface for all OES reader backends.

Mirrors the ir_reader_base.py pattern: every backend implements read() and
returns the same SpectrumReading shape, so scan_manager.py doesn't care
which backend is plugged in.
"""

from __future__ import annotations
import time
from dataclasses import dataclass, field
from typing import Optional
import numpy as np


@dataclass
class SpectrumReading:
    wavelengths: Optional[np.ndarray]   # nm, None if read failed
    intensities: Optional[np.ndarray]   # a.u., None if read failed
    integration_time_us: int
    num_averages: int
    boxcar_width: int
    saturated: bool
    timestamp: float
    error: Optional[str] = None
    # 2026-10-14 (Batch 1): `intensities` is the PROCESSED spectrum
    # (frame-averaged, then boxcar-smoothed if boxcar_width > 0).
    # `raw_intensities` is the same frame average BEFORE any smoothing --
    # the detector values, kept so smoothing never destroys data. Equal
    # to `intensities` when boxcar_width == 0.
    raw_intensities: Optional[np.ndarray] = None
    # Acquisition window (Unix epoch s): first frame started / last frame
    # returned. `timestamp` == acq_start for backward compatibility.
    acq_start: Optional[float] = None
    acq_end: Optional[float] = None
    # Brightest single-frame pixel before averaging -- saturation is judged
    # on this, since averaging can pull one saturated frame below the limit.
    max_frame_count: Optional[float] = None


class SpectrometerReader:
    """Base interface. All backends implement read() and set_integration_time()."""

    @property
    def wavelengths(self) -> Optional[np.ndarray]:
        """
        The device's wavelength calibration array, if known.

        Every backend sets self._wavelengths once at __init__/connect
        time (pyseabreeze/oceandirect from the hardware, mock from
        wavelength_range_nm) -- independent of whether any read() has
        succeeded. Callers (ScanManager) use this to pre-size OESStore
        before the scan's first point is measured, so a first-point read
        or motion failure doesn't crash the whole scan for lack of a
        wavelength array to size the HDF5 file with. None if the reader
        never connected (e.g. pyseabreeze/oceandirect init failed) --
        there's no calibration to fall back on in that case.
        """
        return getattr(self, "_wavelengths", None)

    @property
    def calibration_record(self) -> Optional[dict]:
        """
        Provenance + validity of the wavelength axis as a plain dict
        (see readers/wavelength_calibration.py), or None for backends
        that don't build one from hardware (mock, unimplemented
        oceandirect). ScanManager writes this into metadata.yaml and
        oes.h5 and warns loudly when valid is False.
        """
        cal = getattr(self, "wavelength_calibration", None)
        return cal.to_record() if cal is not None else None

    def read(self) -> SpectrumReading:
        raise NotImplementedError

    def set_integration_time(self, integration_time_us: int):
        raise NotImplementedError

    def apply_settings(self, integration_time_us: int, num_averages: int,
                       boxcar_width: int):
        """
        Apply all three acquisition settings at once (Batch 1). Backends
        that can return a stale frame after a settings change must
        discard it on their next read() -- see PySeabreezeSpectrometerReader.
        """
        self.num_averages = int(num_averages)
        self.boxcar_width = int(boxcar_width)
        self.set_integration_time(int(integration_time_us))

    def acquisition_record(self) -> dict:
        """Settings actually applied to the device, for metadata/HDF5."""
        max_i = getattr(self, "_max_intensity", None)
        return {
            "integration_time_us": int(getattr(self, "integration_time_us", 0)),
            "num_averages": int(getattr(self, "num_averages", 1)),
            "boxcar_width": int(getattr(self, "boxcar_width", 0)),
            "boxcar_window_pixels": 2 * int(getattr(self, "boxcar_width", 0)) + 1,
            "saturation_threshold_counts": float(max_i) if max_i is not None else None,
            "discard_first_frame_after_settings_change": True,
            "smoothing_applied_to": "intensity only; intensity_raw is unsmoothed",
            "response_correction": "none (uncorrected detector counts)",
            "dark_correction": "none",
            "backend": type(self).__name__,
            "model": getattr(getattr(self, "spec", None), "model", None),
            "serial": getattr(getattr(self, "spec", None), "serial_number", None),
        }

    def close(self):
        pass


def boxcar_smooth(intensities: np.ndarray, width: int) -> np.ndarray:
    """
    Centered moving-average smoothing across `width` adjacent points on
    each side (a (2*width + 1)-wide boxcar). width <= 0 returns the input
    unchanged.

    Shared by every spectrometer backend (pyseabreeze, oceandirect, mock)
    so there's one definition of "boxcar smoothing" instead of one
    copy-pasted into each backend file.
    """
    if width <= 0:
        return intensities
    kernel = np.ones(2 * width + 1) / (2 * width + 1)
    return np.convolve(intensities, kernel, mode="same")


def get_spectrometer_reader(config) -> "SpectrometerReader":
    """
    Factory. Returns the appropriate SpectrometerReader based on
    config["oes"]["backend"]:
      "pyseabreeze" → PySeabreezeSpectrometerReader (real hardware)
      "mock"        → MockSpectrometerReader
      None          → MockSpectrometerReader
    """
    oes_cfg = config.get("oes", {})
    backend = oes_cfg.get("backend")
    integration_time_us = oes_cfg.get("integration_time_us", 20000)
    num_averages = oes_cfg.get("num_averages", 3)
    boxcar_width = oes_cfg.get("boxcar_width", 2)

    if backend == "pyseabreeze":
        from .pyseabreeze_spectrometer_reader import PySeabreezeSpectrometerReader
        return PySeabreezeSpectrometerReader(
            integration_time_us=integration_time_us,
            num_averages=num_averages,
            boxcar_width=boxcar_width,
            wavelength_calibration=oes_cfg.get("wavelength_calibration"),
        )

    if backend == "oceandirect":
        from .oceandirect_spectrometer_reader import OceanDirectSpectrometerReader
        return OceanDirectSpectrometerReader(
            integration_time_us=integration_time_us,
            num_averages=num_averages,
            boxcar_width=boxcar_width,
        )

    if backend not in (None, "mock"):
        raise ValueError(f"Unknown oes.backend: {backend!r}. Expected 'pyseabreeze', 'oceandirect', or 'mock'.")

    from .mock_spectrometer_reader import MockSpectrometerReader
    return MockSpectrometerReader(
        integration_time_us=integration_time_us,
        num_averages=num_averages,
        boxcar_width=boxcar_width,
    )
