"""
ir_reader_base.py — shared interface for all IR temperature reader backends.

Every backend (REST API, OptoMMP, direct tap, mock) implements this same
interface so scan_manager.py doesn't care which one is plugged in.
"""

from __future__ import annotations
import statistics
import time
from dataclasses import dataclass
from typing import Optional, Tuple


# Prefix of ir_error_detail for a pyrometer-LOW point; the GUI status
# panels match on it to show "LOW" instead of a generic read error.
IR_LOW_PREFIX = "pyrometer LOW"


@dataclass
class IRReading:
    value_c: float
    emissivity: float
    pac_timestamp: Optional[float]   # epoch seconds; None if read failed
    read_time: float                 # epoch seconds, wall clock at read
    stale: bool                      # True if value/timestamp can't be trusted
    error: Optional[str] = None
    dilution: Optional[float] = None  # pyro signal dilution strength; None if
                                       # no dilution tag configured (ir.pac.dilution_tag_name)
    # True when the value is the pyrometer's LOW output, not a temperature:
    # below its minimum readable temperature / no usable signal (2026-10-06:
    # the PAC reports LOW as a 300.0 C placeholder; the Williamson's real
    # minimum is 600 C -- see ir.pac.min_valid_c). value_c is left as
    # reported, NOT NaN: the adaptive scan's edge detector legitimately
    # uses "reads low" as "off-wafer". Only read_averaged() (the precision
    # scan's dwell average) excludes these, since a LOW is not a reading
    # that can be averaged into a temperature.
    below_range: bool = False


class IRReader:
    """Base interface. All backends implement read()."""

    def read(self) -> IRReading:
        raise NotImplementedError

    def read_averaged(self, averaging_time_s: float,
                      poll_interval_s: float = 0.1,
                      min_reads: int = 3) -> Tuple[float, float, IRReading]:
        """
        Poll read() for averaging_time_s, return (mean_value_c, std_value_c,
        last_reading). Skips stale/errored readings. Both mean and std are
        NaN if no valid reads collected.

        std_value_c (PR-Stage2, 2026-09-09): population standard deviation
        of the same valid_values this method was already collecting to
        compute the mean -- previously that list was discarded right after
        averaging, so signal-quality information that was already being
        measured (how noisy was this point's dwell window) never reached
        the caller. statistics.pstdev is well-defined at n=1 (returns 0.0)
        unlike statistics.stdev (n>=2 required) -- this is a description of
        within-dwell variability, not an inferential sample statistic, so
        pstdev is the right one. Not multiplied/scaled by anything; callers
        that want a different quality proxy (e.g. valid-vs-attempted read
        count) can add one later without touching this return shape again,
        since std alone was the smaller, cheaper addition to make first.

        Bounded (2026-10-06): this loop used to run until it had min_reads
        VALID reads with no deadline at all, so a point where every read
        was invalid (PyroTempInvalid stuck on, PAC unreachable, pyrometer
        LOW) hung the scan forever -- and Stop couldn't interrupt it.
        Now: if the whole dwell window produced zero valid reads, return
        NaN at t_end (waiting longer won't change a cold reactor); if it
        produced some but fewer than min_reads, keep polling for at most
        one extra dwell window (min 2 s), then return what it has.
        below_range (LOW) readings are excluded like stale/errored ones.
        """
        valid_values = []
        last_reading = None
        t_start = time.time()
        t_end = t_start + averaging_time_s
        t_deadline = t_end + max(2.0, averaging_time_s)

        while True:
            reading = self.read()
            last_reading = reading
            if (not reading.stale and reading.error is None
                    and not getattr(reading, "below_range", False)):
                valid_values.append(reading.value_c)
            now = time.time()
            if now >= t_end:
                if len(valid_values) >= min_reads or not valid_values or now >= t_deadline:
                    break
            time.sleep(poll_interval_s)

        if valid_values:
            mean_val = float(sum(valid_values) / len(valid_values))
            std_val = float(statistics.pstdev(valid_values))
        else:
            mean_val = float("nan")
            std_val = float("nan")
        return mean_val, std_val, last_reading

    def close(self):
        pass


def get_ir_reader(config) -> "IRReader":
    """
    Factory. Returns the appropriate IRReader based on config["ir"]["source"]:
      "pac"   → RestApiIRReader (live PAC REST API)
      "mock"  → MockIRReader
      None    → MockIRReader
    """
    source = config.get("ir", {}).get("source")

    if source == "pac":
        from .rest_ir_reader import RestApiIRReader
        ir_cfg = config["ir"]["pac"]

        # Fail with a clear pointer at the missing config key rather than
        # a bare KeyError('temp_tag_name') -- that message alone doesn't
        # say WHERE to fix it, and shows up unhelpfully as "Failed to
        # initialize scan hardware: 'temp_tag_name'" in the GUI's error
        # dialog. ip/api_key_id/api_key_value are left as plain [] lookups
        # since those are always operator-filled during setup and their
        # KeyErrors are self-explanatory by name; temp_tag_name is the one
        # that's easy to leave blank/typo'd (empty string is also
        # rejected -- an empty tag name would silently 404 every read).
        temp_tag_name = ir_cfg.get("temp_tag_name")
        if not temp_tag_name:
            raise ValueError(
                "ir.pac.temp_tag_name is missing or blank in config.yaml. "
                "This must be the REST strategy variable name that holds "
                "the converted IR temperature (confirmed value in this "
                "project: 'iai_PYRO_TEMP'). See readers/rest_ir_reader.py's "
                "module docstring for how to find it in PAC Control if it's "
                "changed."
            )

        return RestApiIRReader(
            controller_ip=ir_cfg["ip"],
            api_key_id=ir_cfg["api_key_id"],
            api_key_value=ir_cfg["api_key_value"],
            temp_tag_name=temp_tag_name,
            # Defaults to the confirmed tag if the config predates this
            # field — set ir.pac.emissivity_tag_name explicitly to override.
            emissivity_tag_name=ir_cfg.get("emissivity_tag_name", "iai_PYRO_EMISSIVITY"),
            # Optional — blank/absent until the real tag name is confirmed
            # (see tools/list_pac_strategy_vars.py). Dilution is simply
            # skipped (IRReading.dilution stays None) until this is set,
            # rather than failing the whole IR read.
            dilution_tag_name=ir_cfg.get("dilution_tag_name") or None,
            # Pyrometer LOW threshold. Defaulted in code (not just in
            # config.example.yaml) because live config.yaml is per-machine
            # and gitignored -- an existing on-site config must get the
            # protection without anyone hand-editing it. Set to null in
            # config.yaml to disable.
            min_valid_c=ir_cfg.get("min_valid_c", 600.0),
        )

    if source not in (None, "mock"):
        raise ValueError(f"Unknown ir.source: {source!r}. Expected 'pac' or 'mock'.")

    from .mock_ir_reader import MockIRReader
    return MockIRReader()
