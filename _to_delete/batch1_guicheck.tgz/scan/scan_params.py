"""
scan_params.py

Shared scan-parameter definitions and validation, used by both
scan_manager.py (runtime scan execution) and calibrate_scan_area.py
(interactive edge calibration + parameter entry).

Operator-facing scan parameters are dwell time (per-point IR averaging
duration) and step size (grid spacing in mm). Grid point counts (nx, ny)
are DERIVED from step size and the edge-calibrated scan range — they are
not set directly in config.yaml. See grid_dims_from_range() below and
scan.grid in config.yaml.
"""

from __future__ import annotations

# --- repo-root import bootstrap -------------------------------------------
# Added PR2a (2026-09-04): this module's __main__ self-check now exercises
# solve_step_size_for_target_points() (scan_manager.py) via a local import,
# so `python scan/scan_params.py` needs the repo root on sys.path the same
# way scan_manager.py and calibrate_scan_area.py already do for themselves
# -- see scan_manager.py's own copy of this comment for the full rationale.
# Harmless as an import-time no-op for every OTHER caller of this module
# (gui/, calibrate_scan_area.py, scan_manager.py itself), since they
# already put the repo root on sys.path before importing scan_params.
import os as _os
import sys as _sys

_REPO_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
if _REPO_ROOT not in _sys.path:
    _sys.path.insert(0, _REPO_ROOT)
# ---------------------------------------------------------------------------

import math

DWELL_TIME_DEFAULT_S = 8.0
DWELL_TIME_MIN_S = 2.0
DWELL_TIME_MAX_S = 22.0

STEP_SIZE_DEFAULT_MM = 2.0
STEP_SIZE_MIN_MM = 1.0
STEP_SIZE_MAX_MM = 11.0

# Number of full grid passes per scan. 1 = old behavior (single pass; only
# the fixed reference_point gets revisited). >1 repeats the ENTIRE grid
# that many times so every point gets rechecked over the course of the
# scan — needed for per-XY-point drift/oscillation tracking (T/e over
# time); a single fixed reference point can't give you that. Upper bound
# is a sanity cap, not a hardware limit — raise it if a real use case
# needs more.
PASSES_DEFAULT = 1
PASSES_MIN = 1
PASSES_MAX = 50

# Scan-time preview warn threshold: the written requirement is "scan should
# take less than 30 minutes; warn the operator if the current parameters
# would exceed it." This is only a UI-preview threshold (used by
# calibration_panel.py's live preview and calibrate_scan_area.py's CLI
# preview), not an execution-time cap -- scans are never blocked from
# running past it, just flagged before the operator commits to them via
# "Write to config.yaml" / the y/N prompt.
SCAN_TIME_WARNING_THRESHOLD_S = 1800.0


def validate_dwell_time_s(dwell_time_s: float) -> float:
    """Raise ValueError if dwell_time_s is outside the operator-valid range."""
    dwell_time_s = float(dwell_time_s)
    if not (DWELL_TIME_MIN_S <= dwell_time_s <= DWELL_TIME_MAX_S):
        raise ValueError(
            f"dwell_time_s={dwell_time_s} outside valid range "
            f"[{DWELL_TIME_MIN_S}, {DWELL_TIME_MAX_S}] seconds"
        )
    return dwell_time_s


def validate_step_size_mm(step_size_mm: float) -> float:
    """Raise ValueError if step_size_mm is outside the operator-valid range."""
    step_size_mm = float(step_size_mm)
    if not (STEP_SIZE_MIN_MM <= step_size_mm <= STEP_SIZE_MAX_MM):
        raise ValueError(
            f"step_size_mm={step_size_mm} outside valid range "
            f"[{STEP_SIZE_MIN_MM}, {STEP_SIZE_MAX_MM}] mm"
        )
    return step_size_mm


def grid_dims_from_range(x_range_mm, y_range_mm, step_size_mm: float):
    """
    Derive (nx, ny) grid point counts from an edge-calibrated scan range
    and a step size in mm.

    A zero-width range on one axis (e.g. x0 == x1) collapses that axis to
    a single point — this is how a 1D line scan falls naturally out of the
    2D grid machinery; "if X changes and Y doesn't, the map ends up a
    line" per spec, with no special-casing needed elsewhere in the code.

    Rounds span/step_size to 6 decimal places before the integer round().
    Without this, ordinary floating-point noise carried through
    calibrate_scan_area.py's edge/deg-per-mm math (e.g. a span landing
    at 74.99999999999999 instead of an intended 75.0) can fall on the
    opposite side of round()'s tie-break boundary than the same nominal
    value does after being serialized to config.yaml at 4 decimal places
    and reloaded by scan_manager.py in a fresh process — silently
    disagreeing on nx/ny between the calibration preview and the grid the
    scan actually runs (seen 2026-07-17: preview said 8x8=64, scan ran
    9x9=81). 6 decimal places (1e-6 mm) is far finer than any real
    deg_per_mm calibration can resolve (~1e-4 mm at best), so this only
    absorbs float noise — it never masks a real, intended distinction.
    """
    step_size_mm = validate_step_size_mm(step_size_mm)

    def _dim(lo, hi):
        span = abs(hi - lo)
        if span == 0:
            return 1
        ratio = round(span / step_size_mm, 6)
        return int(round(ratio)) + 1

    x0, x1 = x_range_mm
    y0, y1 = y_range_mm
    nx = _dim(x0, x1)
    ny = _dim(y0, y1)
    return nx, ny


_RADIUS_TOL_MM = 1e-6


def in_radius(x_mm: float, y_mm: float, center_mm, radius_mm: float) -> bool:
    """
    True if (x_mm, y_mm) is within radius_mm of center_mm.

    Shared by scan_manager.generate_grid() (which grid points actually
    get measured) and calibrate_scan_area.py's preview (how many points
    that will be) so the two can't independently disagree the way the
    rectangular-grid preview/execution counts once did (see
    grid_dims_from_range()'s docstring and the 2026-07-17 diagnosis).

    Exists because a rectangular scan range (x_range_mm x y_range_mm) is
    a bounding box around a circular wafer, not the wafer itself — its
    corners are, by construction, off-sample. Masking the grid down to a
    circle means those corner points are never measured at all: no
    wasted/meaningless off-wafer data, and no motion command is ever
    issued to the largest-excursion points in the grid, which is also
    where the mount's own separate mechanical travel limit (independent
    of wafer shape) is most likely to be exceeded.

    Boundary points count as inside, with a 1e-6 mm tolerance
    (_RADIUS_TOL_MM). 2026-10-02 on-site: diameter 10 / step 5 queued 4
    points instead of 5 -- with center (-6.219, 1.9891) the -X edge point
    came out at d^2 - r^2 = +1.07e-14 from float noise in
    linspace(cx - r, cx + r, n) and was masked off, while the mirror-image
    +X point landed exactly on r and was kept. Same 1e-6 mm scale as
    grid_dims_from_range()'s rounding: far below anything the calibration
    can resolve, so it only absorbs float noise.
    """
    cx, cy = center_mm
    return math.hypot(x_mm - cx, y_mm - cy) <= radius_mm + _RADIUS_TOL_MM


def endpoint_from_angle(start_mm, angle_deg: float, length_mm: float):
    """
    PR2b (2026-09-08): the operator-facing line-scan input is one
    endpoint + an angle + a length, not two typed-in endpoints -- this
    computes the SECOND endpoint from the first, so generate_line_points()
    below still only ever has to deal with two explicit (x_mm, y_mm)
    endpoints regardless of which way the operator entered the line.

    Angle convention -- standard math convention in the SCAN-PLANE
    (x_mm, y_mm) frame: angle_deg=0 points along +x_mm, increasing
    COUNTERCLOCKWISE toward +y_mm. This is deliberately NOT the same
    "degrees" as anywhere else in this codebase -- motion_controller.py,
    real_conexagap_motion.py, and real_mr1530_motion.py all use
    "degrees" to mean physical mirror/mount tilt, a completely different
    hardware-frame unit that gets converted to scan-plane mm via
    deg_per_mm_x/y. There is no risk of these colliding in code (this
    function never touches motion/), but the SAME WORD meaning two
    different things in one codebase is exactly the kind of mixup the
    s_mm-vs-x_mm naming decision elsewhere in PR2b was trying to avoid --
    called out explicitly here for the same reason.

    Returns (x_mm, y_mm) -- the computed second endpoint. Does NOT
    validate against a calibrated wafer or motion.soft_limits; both
    start_mm and this returned endpoint should be checked with
    in_radius() (wafer shape) before being handed to
    generate_line_points(), same as gui/line_scan_panel.py does -- this
    function is pure geometry, no knowledge of calibration state.
    """
    x0, y0 = start_mm
    angle_rad = math.radians(angle_deg)
    x1 = x0 + length_mm * math.cos(angle_rad)
    y1 = y0 + length_mm * math.sin(angle_rad)
    return float(x1), float(y1)


def find_out_of_limits(points_xy, limits):
    """
    Return a list of (label, x_mm, y_mm, reason) for every (label, x_mm,
    y_mm) triple in points_xy that falls outside the soft limits dict
    (x_min_mm/x_max_mm/y_min_mm/y_max_mm — same shape as
    motion.soft_limits in config.yaml and the same keys
    MotionController.check_limits() checks).

    Does NOT raise and does NOT stop at the first violation — checks
    every point against both axes independently and returns the full
    list. This is what makes a pre-flight scan check useful for
    debugging: MotionController.check_limits() (used per-point, during
    the scan) raises on the FIRST bad axis of the FIRST bad point, which
    is enough to stop a scan safely but not enough to see "is this one
    bad corner, or is the whole grid offset" at a glance before
    anything moves.
    """
    x_min, x_max = limits["x_min_mm"], limits["x_max_mm"]
    y_min, y_max = limits["y_min_mm"], limits["y_max_mm"]
    violations = []
    for label, x, y in points_xy:
        reasons = []
        if not (x_min <= x <= x_max):
            reasons.append(f"x={x:.4f} outside [{x_min}, {x_max}]")
        if not (y_min <= y <= y_max):
            reasons.append(f"y={y:.4f} outside [{y_min}, {y_max}]")
        if reasons:
            violations.append((label, x, y, "; ".join(reasons)))
    return violations


def validate_points_within_limits(points_xy, limits, max_shown: int = 20):
    """
    Raise ValueError if any (label, x_mm, y_mm) in points_xy falls
    outside limits, listing every violation (up to max_shown) with its
    label, position, and which bound it broke.

    Intended to run BEFORE any motion controller is connected or homed —
    see scan_manager.preflight_check(). This checks the same
    x_min_mm/x_max_mm/y_min_mm/y_max_mm bounds as
    MotionController.check_limits(), just over the WHOLE commanded
    position list at once and before anything moves, rather than one
    point at a time as each move is issued mid-scan. It does not replace
    the per-point check_limits() call in scan_manager._measure_point —
    that stays in place as defense in depth (e.g. if soft_limits itself
    were ever edited mid-process, or this function's caller forgot to
    include some position this one doesn't know about).
    """
    violations = find_out_of_limits(points_xy, limits)
    if not violations:
        return
    lines = [f"  {label}: ({x:.4f}, {y:.4f}) mm — {reason}"
             for label, x, y, reason in violations[:max_shown]]
    if len(violations) > max_shown:
        lines.append(f"  ...and {len(violations) - max_shown} more")
    raise ValueError(
        f"{len(violations)} of {len(points_xy)} commanded position(s) fall outside "
        f"motion.soft_limits (x: [{limits['x_min_mm']}, {limits['x_max_mm']}], "
        f"y: [{limits['y_min_mm']}, {limits['y_max_mm']}]) — refusing to start. "
        "No motion has been commanded.\n" + "\n".join(lines)
    )


def validate_passes(passes: int) -> int:
    """Raise ValueError if passes is outside the operator-valid range."""
    passes = int(passes)
    if not (PASSES_MIN <= passes <= PASSES_MAX):
        raise ValueError(
            f"passes={passes} outside valid range [{PASSES_MIN}, {PASSES_MAX}]"
        )
    return passes


def estimate_scan_time_s(nx: int, ny: int, dwell_time_s: float, settle_time_s: float = 0.0,
                          passes: int = 1) -> float:
    """
    Rough total scan time estimate: point count * (dwell + settle) * passes.

    Does NOT include reference-point revisits or periodic rehomes (both
    optional and config-dependent) — this is the grid-only floor.
    """
    return nx * ny * passes * (dwell_time_s + settle_time_s)


# --------------------------------------------------------------------------
# OES acquisition settings (Batch 1, 2026-10-14). Operator-editable on the
# Scan and Line Scan tabs; defaults come from config.yaml's oes: block and
# the values actually applied are recorded with every scan.
#   integration: ADC1000/S2000-class benches accept ~3 ms .. 60 s.
#   boxcar_width: HALF-width -- w smooths over (2w + 1) pixels, so 1 is a
#   3-pixel average and only 0 means "no smoothing". Smoothing is applied
#   to the processed `intensity` copy only; `intensity_raw` is never smoothed.
# --------------------------------------------------------------------------
INTEGRATION_TIME_MIN_US = 3_000
INTEGRATION_TIME_MAX_US = 60_000_000
NUM_AVERAGES_MIN = 1
NUM_AVERAGES_MAX = 1000
BOXCAR_WIDTH_MIN = 0
BOXCAR_WIDTH_MAX = 50


def _as_int(value, name):
    try:
        f = float(value)
    except (TypeError, ValueError):
        raise ValueError(f"{name} must be a number, got {value!r}")
    if f != int(f):
        raise ValueError(f"{name} must be a whole number, got {value!r}")
    return int(f)


def validate_integration_time_us(value) -> int:
    v = _as_int(value, "integration_time_us")
    if not (INTEGRATION_TIME_MIN_US <= v <= INTEGRATION_TIME_MAX_US):
        raise ValueError(
            f"integration_time_us={v} outside valid range "
            f"[{INTEGRATION_TIME_MIN_US}, {INTEGRATION_TIME_MAX_US}]")
    return v


def validate_num_averages(value) -> int:
    v = _as_int(value, "num_averages")
    if not (NUM_AVERAGES_MIN <= v <= NUM_AVERAGES_MAX):
        raise ValueError(
            f"num_averages={v} outside valid range [{NUM_AVERAGES_MIN}, {NUM_AVERAGES_MAX}]")
    return v


def validate_boxcar_width(value) -> int:
    v = _as_int(value, "boxcar_width")
    if not (BOXCAR_WIDTH_MIN <= v <= BOXCAR_WIDTH_MAX):
        raise ValueError(
            f"boxcar_width={v} outside valid range [{BOXCAR_WIDTH_MIN}, {BOXCAR_WIDTH_MAX}]")
    return v


def oes_acquisition_time_s(integration_time_us: int, num_averages: int) -> float:
    """Time one OES read takes (+1 discarded frame only after a change)."""
    return integration_time_us * 1e-6 * num_averages


if __name__ == "__main__":
    # Smoke test
    assert grid_dims_from_range([0, 50], [0, 50], 2.0) == (26, 26)
    assert grid_dims_from_range([0, 0], [0, 40], 2.0) == (1, 21)  # degenerate X -> line scan
    assert grid_dims_from_range([10, 10], [5, 5], 2.0) == (1, 1)  # degenerate both -> point scan

    # Regression for 2026-07-17: span/step landing exactly on round()'s
    # .5 tie-break boundary (75mm / 10mm = 7.5) must resolve the SAME way
    # whether fed the noisy live float (74.99999999999999, as computed
    # in-process by calibrate_scan_area.py before writing to disk) or the
    # clean value it round-trips to after being written at 4 decimal
    # places and reloaded by scan_manager.py — otherwise the calibration
    # preview and the executed scan silently disagree on grid size.
    assert grid_dims_from_range([-50.84745762711864, 24.152542372881353],
                                 [-57.77166437414029, 17.228335625859696], 10.0) == (9, 9)
    assert grid_dims_from_range([-50.8475, 24.1525], [-57.7717, 17.2283], 10.0) == (9, 9)

    try:
        validate_step_size_mm(15)
        raise AssertionError("expected ValueError for step_size_mm out of range")
    except ValueError:
        pass

    try:
        validate_dwell_time_s(1)
        raise AssertionError("expected ValueError for dwell_time_s out of range")
    except ValueError:
        pass

    try:
        validate_passes(0)
        raise AssertionError("expected ValueError for passes out of range")
    except ValueError:
        pass
    assert validate_passes(3) == 3

    # in_radius(): center included, a bounding-box corner excluded, a
    # cardinal edge point included (on the circle, not past it).
    assert in_radius(0, 0, (0, 0), 25.0) is True
    assert in_radius(25, 25, (0, 0), 25.0) is False   # bounding-box corner, off-wafer
    assert in_radius(25, 0, (0, 0), 25.0) is True     # exactly on the circle
    assert in_radius(0, -25, (5, -5), 25.0) is True   # off-origin center

    # find_out_of_limits() / validate_points_within_limits(): all-in,
    # one-out-of-two-axes, and the "don't stop at the first violation"
    # behavior that per-point check_limits() can't give you.
    limits = {"x_min_mm": -10, "x_max_mm": 10, "y_min_mm": -5, "y_max_mm": 5}
    all_ok = [("a", 0, 0), ("b", 10, 5), ("c", -10, -5)]
    assert find_out_of_limits(all_ok, limits) == []
    validate_points_within_limits(all_ok, limits)  # must not raise

    mixed = [("a", 0, 0), ("b", 11, 0), ("c", 0, 6), ("d", 11, 6)]
    violations = find_out_of_limits(mixed, limits)
    assert [v[0] for v in violations] == ["b", "c", "d"]  # "a" excluded, order preserved
    assert "x=11.0000" in violations[0][3] and "y" not in violations[0][3]
    assert "y=6.0000" in violations[1][3] and "x" not in violations[1][3]
    assert "x=11.0000" in violations[2][3] and "y=6.0000" in violations[2][3]  # both axes bad

    try:
        validate_points_within_limits(mixed, limits)
        raise AssertionError("expected ValueError for out-of-limits points")
    except ValueError as e:
        msg = str(e)
        assert "3 of 4" in msg
        assert "b" in msg and "c" in msg and "d" in msg  # every violation listed, not just first

    est = estimate_scan_time_s(*grid_dims_from_range([0, 50], [0, 50], 2.0), dwell_time_s=8.0)
    print(f"26x26 grid @ 8s dwell, 1 pass -> {est/60:.1f} min estimated scan time")
    est3 = estimate_scan_time_s(*grid_dims_from_range([0, 50], [0, 50], 2.0), dwell_time_s=8.0, passes=3)
    assert est3 == est * 3
    print(f"26x26 grid @ 8s dwell, 3 passes -> {est3/60:.1f} min estimated scan time")

    # Regression for 2026-09-03: calibration_panel.py and
    # calibrate_scan_area.py both call this with the WAFER-MASKED point
    # count (not nx*ny) passed as nx with ny=1, since the circular mask
    # excludes corner/off-wafer positions the bounding-box grid would
    # otherwise overstate -- confirm that call shape still resolves to
    # n_points * passes * (dwell + settle) with settle_time_s included.
    est_masked = estimate_scan_time_s(529, 1, dwell_time_s=2.0, settle_time_s=0.5, passes=1)
    assert est_masked == 529 * (2.0 + 0.5)
    est_masked_passes = estimate_scan_time_s(529, 1, dwell_time_s=2.0, settle_time_s=0.5, passes=2)
    assert est_masked_passes == est_masked * 2
    print(f"529-point masked grid @ 2.0s dwell + 0.5s settle, 1 pass -> "
          f"{est_masked/60:.1f} min; 2 passes -> {est_masked_passes/60:.1f} min")

    # Regression: SCAN_TIME_WARNING_THRESHOLD_S itself is exercised as a
    # plain comparison at both call sites, not a function -- just confirm
    # it's the documented 30 minutes so a future edit here doesn't silently
    # change the warning's meaning without updating the docstring/comment.
    assert SCAN_TIME_WARNING_THRESHOLD_S == 1800.0

    # PR2a (2026-09-04): solve_step_size_for_target_points() lives in
    # scan_manager.py, not here (it needs generate_grid() to count points,
    # and scan_manager.py already imports this module -- the reverse
    # import would be circular). Exercise it here anyway, via a LOCAL
    # import (same pattern gui/calibration_panel.py and
    # calibrate_scan_area.py already use to reach generate_grid()) --
    # this stays the one place in the repo with a real regression
    # self-check, per the 2026-08-05 test-coverage-gap finding.
    from scan.scan_manager import solve_step_size_for_target_points

    step_500, n_500, ok_500 = solve_step_size_for_target_points((0.0, 0.0), 25.0, 500)
    assert ok_500 and n_500 >= 500
    print(f"solve_step_size_for_target_points: target 500 pts, r=25mm -> "
          f"step={step_500}mm, {n_500} pts, achieved={ok_500}")

    # Finer target must never resolve to a COARSER step than a looser one
    # -- otherwise the "at least N, never fewer" contract is broken.
    step_loose, n_loose, _ = solve_step_size_for_target_points((0.0, 0.0), 25.0, 200)
    step_tight, n_tight, _ = solve_step_size_for_target_points((0.0, 0.0), 25.0, 800)
    assert step_tight <= step_loose and n_tight >= 800 and n_loose >= 200

    # Infeasible case (target unreachable even at the 1mm step floor)
    # must report achieved=False with the max actually achievable, not
    # silently return an undersized scan.
    step_inf, n_inf, ok_inf = solve_step_size_for_target_points((0.0, 0.0), 2.0, 10000)
    assert not ok_inf and step_inf == STEP_SIZE_MIN_MM

    # PR2b (2026-09-08): generate_line_points() lives in scan_manager.py,
    # not here -- same reasoning as solve_step_size_for_target_points()
    # just above (this file stays the one place with a real regression
    # self-check; scan_manager.py's own __main__ is the CLI entry point,
    # not a test harness). Exercised via the same local-import pattern.
    from scan.scan_manager import generate_line_points

    # A 3-4-5 triangle (start at origin, end at (3,4), length exactly 5)
    # so the closed-form spacing is exact and easy to hand-check.
    line_pts = generate_line_points((0.0, 0.0), (3.0, 4.0), 6)
    assert len(line_pts) == 6
    # Both endpoints exactly reproduced -- i=0 at start_mm (s_mm=0.0),
    # i=N-1 at end_mm (s_mm=length).
    i0, x0, y0, s0 = line_pts[0]
    assert (i0, x0, y0, s0) == (0, 0.0, 0.0, 0.0)
    iN, xN, yN, sN = line_pts[-1]
    assert iN == 5 and abs(xN - 3.0) < 1e-9 and abs(yN - 4.0) < 1e-9 and abs(sN - 5.0) < 1e-9

    # Evenly spaced: s_mm step = length / (n_points - 1) = 5/5 = 1.0mm,
    # exact closed-form -- no bisection, no rounding drift to guard
    # against the way PR2a's step solver needed.
    s_values = [s for _i, _x, _y, s in line_pts]
    steps = [round(s_values[k + 1] - s_values[k], 9) for k in range(len(s_values) - 1)]
    assert all(step == 1.0 for step in steps), steps

    # i is a plain 0-based index in generation order, monotonically
    # increasing -- this is what scan_manager.py's OESStore write path
    # (and, in line mode, the sole spatial index) relies on.
    assert [i for i, _x, _y, _s in line_pts] == list(range(6))

    # n_points=1 collapses to a single point at start_mm, s_mm=0.0 --
    # same "degenerate range -> one point" convention
    # grid_dims_from_range() already uses.
    single = generate_line_points((5.0, -5.0), (25.0, 25.0), 1)
    assert single == [(0, 5.0, -5.0, 0.0)]

    # n_points=0 (or negative) is invalid -- unlike a grid's degenerate
    # zero-width axis, a line scan can't have zero points and still mean
    # anything.
    try:
        generate_line_points((0.0, 0.0), (1.0, 1.0), 0)
        raise AssertionError("expected ValueError for n_points=0")
    except ValueError:
        pass

    # endpoint_from_angle() + generate_line_points() together, end to
    # end: an operator-entered start/angle/length must produce the same
    # line generate_line_points() would from two explicitly-typed
    # endpoints -- this is the exact composition
    # gui/line_scan_panel.py's "Solve" button performs.
    start = (2.0, 3.0)
    end = endpoint_from_angle(start, 0.0, 8.0)  # due +x, length 8mm
    composed = generate_line_points(start, end, 5)
    assert abs(composed[-1][1] - 10.0) < 1e-9 and abs(composed[-1][2] - 3.0) < 1e-9
    assert abs(composed[-1][3] - 8.0) < 1e-9

    # compute_commanded_points()/preflight_check() mode dispatch: a
    # line-mode scan_cfg must produce line points (not silently fall
    # through to generate_grid()), and every one of them still gets
    # checked against motion.soft_limits -- same defense-in-depth grid
    # mode already had, now confirmed for line mode too.
    from scan.scan_manager import compute_commanded_points, preflight_check

    line_scan_cfg = {
        "grid": {"mode": "line", "line_start_mm": [0.0, 0.0], "line_end_mm": [8.0, 6.0],
                 "line_n_points": 5},
    }
    commanded = compute_commanded_points(line_scan_cfg)
    assert len(commanded) == 5
    assert all(label.startswith("line point") for label, _x, _y in commanded)
    assert abs(commanded[-1][1] - 8.0) < 1e-9 and abs(commanded[-1][2] - 6.0) < 1e-9

    line_config = {
        "scan": line_scan_cfg,
        "motion": {"soft_limits": {"x_min_mm": -10, "x_max_mm": 10,
                                    "y_min_mm": -10, "y_max_mm": 10}},
    }
    preflight_check(line_config)  # must not raise -- every point is in bounds

    line_config_too_far = {
        "scan": {"grid": {"mode": "line", "line_start_mm": [0.0, 0.0],
                           "line_end_mm": [50.0, 0.0], "line_n_points": 3}},
        "motion": {"soft_limits": {"x_min_mm": -10, "x_max_mm": 10,
                                    "y_min_mm": -10, "y_max_mm": 10}},
    }
    try:
        preflight_check(line_config_too_far)
        raise AssertionError("expected ValueError for a line running past soft_limits")
    except ValueError:
        pass

    # PR2b (2026-09-08): endpoint_from_angle() -- 0 deg along +x, 90 deg
    # along +y (standard math convention, counterclockwise), and a
    # round-trip through in_radius() to confirm the two stay usable
    # together the way gui/line_scan_panel.py relies on.
    ex, ey = endpoint_from_angle((0.0, 0.0), 0.0, 10.0)
    assert abs(ex - 10.0) < 1e-9 and abs(ey - 0.0) < 1e-9, (ex, ey)

    ex, ey = endpoint_from_angle((0.0, 0.0), 90.0, 10.0)
    assert abs(ex - 0.0) < 1e-9 and abs(ey - 10.0) < 1e-9, (ex, ey)

    ex, ey = endpoint_from_angle((5.0, -5.0), 180.0, 5.0)
    assert abs(ex - 0.0) < 1e-9 and abs(ey - -5.0) < 1e-9, (ex, ey)

    # 45 degrees: both axes move by length/sqrt(2).
    ex, ey = endpoint_from_angle((0.0, 0.0), 45.0, 10.0)
    expected = 10.0 / math.sqrt(2)
    assert abs(ex - expected) < 1e-9 and abs(ey - expected) < 1e-9, (ex, ey)

    # A line fully inside a calibrated wafer: both the given start and the
    # computed end must pass in_radius() -- this is exactly the two-point
    # check gui/line_scan_panel.py relies on instead of sampling every
    # point along the line (a circle is convex, so this is sufficient).
    center, radius = (0.0, 0.0), 25.0
    start = (0.0, 0.0)
    end = endpoint_from_angle(start, 30.0, 20.0)
    assert in_radius(start[0], start[1], center, radius)
    assert in_radius(end[0], end[1], center, radius)

    # A line that overshoots the wafer: the computed end must fail
    # in_radius() so the GUI's block/warn path actually has something to
    # catch.
    end_far = endpoint_from_angle(start, 30.0, 100.0)
    assert not in_radius(end_far[0], end_far[1], center, radius)

    print("scan_params smoke test OK")
